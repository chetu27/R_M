<?php

/**
 * @wordpress-plugin
 * Plugin Name:       Khud ki plugin
 * Plugin URI:        Khud ki plugin
 * Description:       Plugin to change Api format to custom formatting
 * Version:           1.0.0
 * Author:            
 * Author URI:        
 * License:           GPL-2.0+
 * Text Domain:       fbag
 * Domain Path:       /languages 
 */




function shortcode_insert_form_function() { ?>
<div class="container">    
    <form type="post" action="" id="insertdata">
        <div class="row">
          <div class="form-group col-sm-6">
            <label >First Name</label>
            <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter Your Name">        
          </div>
          <div class="form-group col-sm-6">
            <label>Last Name</label>
            <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Your Last Name">
          </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('#insertdata').submit(function(event){
            alert('dsgdg');
            event.preventDefault();
            jQuery.ajax({
                data

            });
        });
    });


</script>
<?php }

add_shortcode('insert_form', 'shortcode_insert_form_function');






