jQuery(document).ready(function(){
jQuery("#submit").click(function(){
    var name = jQuery("#dname").val();
    var name1 = jQuery("#dname1").val();
jQuery.ajax({
type: 'POST',
url: MyAjax.ajaxurl,
data: {"action": "post_word_count", "dname":name, "dname1":name1},
success: function(data){
alert(data);
$("#success").show();
$('#success').html('Data added successfully !');
}
});
});
});