<?php
/*
Plugin Name: Ajax Demo Plugin
Plugin URI: http://www.inkthemes.com
Description: My first ajax plugin
Version: 1.0
Author: InkThemes
Author URI: http://www.inkthemes.com
License: Plugin comes under GPL Licence.
*/
//Include Javascript library
wp_enqueue_script('inkthemes', plugins_url( '/js/demo.js' , __FILE__ ) , array( 'jquery' ));
// including ajax script in the plugin Myajax.ajaxurl
wp_localize_script( 'inkthemes', 'MyAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php')));
function post_word_count(){
$name = $_POST['dname'];
$name1 = $_POST['dname1'];
global $wpdb;
$wpdb->insert( 
	'wp_product', 
	array( 
		'product_name' => $name,
		'product_description' => $name1
	), 
	array( 
		'%s'
	) 
);
die();
return true;
}
add_action('wp_ajax_post_word_count', 'post_word_count');
add_action('wp_ajax_nopriv_post_word_count', 'post_word_count');
function show_form(){?>
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
<?php echo "<form>";
echo "<label>Name</label>";
echo "<input type='text' id='dname' name='dname' value=''/><br/>";
echo "<label>Name1</label>";
echo "<input type='text' id='dname1' name='dname1' value=''/><br/>";
echo "<input type='button' id='submit' name='submit' value='Submit'/>";
echo "</form>";
}
add_action('the_content', 'show_form');
?>