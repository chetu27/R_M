<?php
/* Template Name: Home */
get_header(); ?>
<?php 
require_once(dirname( __FILE__ ).'/../../../../wp-config.php');
$conn = new mysqli($servername, $username, $password, $dbname);

$count = mysqli_query($conn,"SELECT * FROM wp_product");
$noofcount = mysqli_num_rows($count);
?>


<div class="container">

<div class="row">
	<!-- <div class="col-sm-1"></div> -->
  <div class="col-sm-6 ">
  	<a href="<?php echo site_url('add-product'); ?>"><div class="boxes">
  Add Product</div></a></div>
  <!-- <div class="col-sm-1"></div> -->
  <div class="col-sm-6"><a href="<?php echo site_url('product-listing'); ?>"><div class="boxes">Product Listing<span> (Number Of Products: <?php echo $noofcount; ?>)</span></div></a> </div>
</div>

<div class="row">
	<!-- <div class="col-sm-1"></div> -->
  <div class="col-sm-6 ">
  	<a href="<?php echo site_url('recipe-add'); ?>"><div class="boxes">
  Add Recipe</div></a></div>
  <!-- <div class="col-sm-1"></div> -->
  <div class="col-sm-6"><a href="<?php echo site_url('recipe-list'); ?>"><div class="boxes">Recipe Listing<span> </span></div></a> </div>
</div>

</div>




<?php get_footer(); ?>
